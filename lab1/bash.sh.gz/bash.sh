#!/bin/bash

# ^ shebang

# cd = change directory
# ls = list
# ls -a 
# ls -Ra

# pwd = present working directory
# mkdir = make directory
# whoami = current user
# rm = remove
# rm -rf = remove recursive forced
# cd .. = parent link 
# ls -i = inode numbers
# grep = find occurences 
# man = manual
# vim = terminal based editor 
# emacs = terminal based editor

echo "Hello World"

